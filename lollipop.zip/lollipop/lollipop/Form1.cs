﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ScottPlot;

namespace lollipop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            double[] values = { 26, 20, 23, 7, 16 };
            var lollipop = formsPlot1.Plot.AddLollipop(values);
            lollipop.Orientation = ScottPlot.Orientation.Vertical;
            lollipop.ShowValuesAboveBars = true;
            lollipop.LollipopColor = Color.Green;
            lollipop.LollipopRadius = 10;
            formsPlot1.Plot.Legend();
            formsPlot1.Refresh();
        }
    }
}
